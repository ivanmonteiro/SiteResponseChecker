Hardcodet NotifyIcon for WPF
****************************

THIS PACKAGE IS OBSOLETE.

This package has a dependency to the official package in order to keep things working for you, but consider switching to the official NuGet package: Hardcodet.NotifyIcon.Wpf

For direct NuGet links, source code or samples, please visit the project page:
http://www.hardcodet.net/projects/wpf-notifyicon