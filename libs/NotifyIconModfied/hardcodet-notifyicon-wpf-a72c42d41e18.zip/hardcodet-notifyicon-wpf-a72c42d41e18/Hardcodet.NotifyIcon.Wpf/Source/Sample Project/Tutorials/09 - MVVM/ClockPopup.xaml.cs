﻿using System.Windows.Controls;

namespace Samples.Tutorials.MvvmSample
{
	/// <summary>
	/// Interaction logic for ClockPopup.xaml
	/// </summary>
	public partial class ClockPopup : UserControl
	{
		public ClockPopup()
		{
			this.InitializeComponent();
		}
	}
}