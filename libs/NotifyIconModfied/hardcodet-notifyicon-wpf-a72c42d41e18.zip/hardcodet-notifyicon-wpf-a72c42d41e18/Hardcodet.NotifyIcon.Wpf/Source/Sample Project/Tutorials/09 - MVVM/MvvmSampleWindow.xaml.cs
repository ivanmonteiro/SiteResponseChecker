﻿using System.Windows;

namespace Samples.Tutorials.MvvmSample
{
    /// <summary>
    /// Interaction logic for MvvmSampleWindow.xaml
    /// </summary>
    public partial class MvvmSampleWindow : Window
    {
        public MvvmSampleWindow()
        {
            InitializeComponent();
        }
    }
}
